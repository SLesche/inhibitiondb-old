download_db <- function(local_path){
  # TODO: Add function to download the db
}
